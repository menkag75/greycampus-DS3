----Create Database ----------------

CREATE DATABASE School;

-----Create Table Students-------
CREATE TABLE Students (
student_id SERIAL PRIMARY KEY, 
first_name varchar(50) NOT NULL,
last_name varchar(50) NOT NULL, 
homeroom_number varchar(30) NOT NULL, 
phone varchar(50) UNIQUE NOT NULL,
email varchar(50) UNIQUE , 
graduation_year int NOT NULL
)

select * from students ;

-----Create Table Teachers-------
CREATE TABLE Teachers (
teacher_id SERIAL PRIMARY KEY, 
first_name varchar(50) NOT NULL,
last_name varchar(50) NOT NULL, 
homeroom_number varchar(30) NOT NULL, 
department	varchar(200) NOT NULL,
email varchar(50) UNIQUE NOT NULL,
phone varchar(50) UNIQUE NOT NULL
)

select * from teachers ;

-----------Insert student data in Students table------

INSERT INTO Students (
first_name ,
last_name , 
homeroom_number , 
phone ,
graduation_year 
)
VALUES (
 'Mark',
 'Watney',
 '5',
 '777-555-1234',
  2035
);
select * from students ;

-----------Insert teachers data in Teachers table -----------

INSERT INTO Teachers (
first_name ,
last_name , 
homeroom_number , 
department,
email,	
phone 
)
VALUES (
	'Jonas',
	'Salk',
	'5',
	'Biology',
	'jsalk@school.org',
	'777-555-4321'
);
	
select * from Teachers ;



