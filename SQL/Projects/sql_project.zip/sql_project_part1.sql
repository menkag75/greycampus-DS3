1. Select * from cd.facilities ;

2. select name , membercost from cd.facilities;

3. Select * from cd.facilities where membercost >0;

4. Select facid, name as facility_name ,membercost , monthlymaintenance from cd.facilities
where membercost > 0 and  membercost < (monthlymaintenance/50) ;

5. Select * from cd.facilities where name ilike '%Tennis%';

6. Select * from cd.facilities WHERE facid IN (1,5);

7. SELECT  memid, surname,firstname,joindate FROM cd.members  
where EXTRACT(MONTH From joindate) >= 9  AND EXTRACT(YEAR From joindate) >= 2012;
--- alternate method  ----SELECT  memid, surname,firstname,joindate FROM cd.members where joindate >='2012-09-01 00:00:00';

8. select distinct(surname) from cd.members order by surname asc LIMIT 10;

9. SELECT joindate FROM cd.members ORDER BY joindate DESC LIMIT 1;

10. SELECT COUNT(guestcost) FROM cd.facilities WHERE guestcost >=10;

11. SELECT  facid , sum(slots) AS Total_Slots from  cd.bookings 
where EXTRACT(MONTH From starttime) = 9  AND EXTRACT(YEAR From starttime) = 2012 
group by facid
order by sum(slots) asc;

12. Select facid , sum(slots) as Total_Slots from cd.bookings 
group by facid 
HAVING sum(slots) > 1000 
order by facid asc

13. SELECT starttime , name FROM cd.bookings 
INNER JOIN cd.facilities
ON cd.bookings.facid = cd.facilities.facid
WHERE cd.facilities.name ILIKE '%Tennis Court%' 
AND TO_CHAR(starttime,'YYYY-MM-DD')= '2012-09-21'
ORDER BY starttime ASC

14. Select starttime from cd.bookings 
inner join cd.members
on cd.bookings.memid = cd.members.memid
where  concat(firstname,' ',surname)  = 'David Farrell'





 


